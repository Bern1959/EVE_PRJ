<TestSuiteEntity>
<description></description>
<name>putTeam2Work</name>
<tag></tag>
<isRerun>false</isRerun>
 <mailRecipient></mailRecipient>
<numberOfRerun>0</numberOfRerun>
<pageLoadTimeout>30</pageLoadTimeout>
<pageLoadTimeoutDefault>true</pageLoadTimeoutDefault> <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
<rerunImmediately>false</rerunImmediately>
<testCaseLink>
<isReuseDriver>false</isReuseDriver>
<isRun>true</isRun>
<testCaseId>Test Cases/LoginPC_10</testCaseId>
<usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
</testCaseLink>
<testCaseLink>
<isReuseDriver>false</isReuseDriver>
<isRun>true</isRun>
<testCaseId>Test Cases/putTeams2Work_20</testCaseId>
<usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
</testCaseLink>
</TestSuiteEntity>