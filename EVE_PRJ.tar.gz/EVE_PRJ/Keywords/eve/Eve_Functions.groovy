
package eve

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import java.awt.RenderingHints.Key
import java.lang.reflect.Executable
import java.util.regex.Matcher
import java.util.regex.Pattern

import org.junit.After
import org.littleshoot.proxy.FlowContext
import org.openqa.selenium.StaleElementReferenceException
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.chrome.ChromeDriver
import org.stringtemplate.v4.compiler.STParser.option_return
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.exception.StepFailedException
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI


public class Eve_Functions {
	// ACTION
	@Keyword
	def openBrowser(String url){
		WebUI.openBrowser(url);

		WebUI.maximizeWindow();

		int w = WebUI.getViewportWidth();
		int h = WebUI.getViewportHeight();

		if(w == 800) WebUI.setViewPortSize(1450, 750);

		w = WebUI.getViewportWidth();
		h = WebUI.getViewportHeight();

		printMessage("Browser opened with url %s", url);
	}

	@Keyword
	def closeBrowser(){
		WebUI.closeBrowser();
		printMessage("Browser closed");
	}

	@Keyword
	def setText(TestObject obj, String text, Boolean pressEnter = false){
		TestObject actual = getObjectReference(obj);
		try{
			// Check if input is disabled
			Boolean inputDisabled = getInputDisabled(actual.findPropertyValue("id"))

			if(inputDisabled){
				printMessage("Input %s is disabled", WebUI.getAttribute(obj, "id"));
				return;
			}

			WebUI.setText(actual, text);

			if(pressEnter) WebUI.sendKeys(actual, Keys.chord(Keys.ENTER));

		}
		catch(Exception e){
			if(handleException(e) != true) setStatus(1, "Failed to set text in object %s", actual.findPropertyValue("id"));
			setText(actual, text, pressEnter);
		}
	}

	@Keyword
	def getTextFromObject(TestObject obj){
		TestObject actual = getObjectReference(obj);

		try{
			return WebUI.getText(actual);
		}
		catch(StepFailedException e){
			if(handleException(e) != true) setStatus(1, "Failed to get text from object %s", actual.findPropertyValue("id"))
			getTextFromObject(actual);
		}
	}

	@Keyword
	def setDropDownOption(TestObject obj, String text, Boolean pressEnter){
		TestObject actual = getObjectReference(obj);

		try{
			Boolean inputDisabled = getInputDisabled(actual.findPropertyValue("id"))

			if(inputDisabled) return;

			WebUI.setText(actual, text);

			if(pressEnter) WebUI.sendKeys(actual, Keys.chord(Keys.ENTER));
			else WebUI.sendKeys(actual, Keys.chord(Keys.TAB))
		}
		catch(Exception e){
			if(handleException(e) != true) setStatus(1, "Failed to write text %s in input %s", text , actual.findPropertyValue("id"))
			setDropDownOption(actual, text, pressEnter);
		}
	}

	@Keyword
	def return2Previous(int menuCount = 1, Boolean confirm = false){
		String linkID = execJS("let ol = document.querySelector(\"ol\"); let count = ol.childNodes.length; return ol.childNodes[(count -1) - " + menuCount +  "].childNodes[0].id");

		TestObject link = new TestObject("Previous Menu");
		link.addProperty("id", ConditionType.EQUALS, linkID);

		clickOnObject(link);

		if(confirm) confirmDialogue();
	}

	@Keyword
	def searchForTransaction(String transactionCode, Boolean directFilterScreen){
		waitForDom2BeStill()
		TestObject menuSearch = new TestObject("Menu Search Bar");
		menuSearch.addProperty("id", ConditionType.EQUALS, "menuSearch-I");

		setText(menuSearch, transactionCode, true);

		if(directFilterScreen) goToFilterScreen();
	}

	@Keyword
	def checkIfEqual(Object first, Object second){
		return first == second;
	}

	@Keyword
	def selectLine(int lineIndex ,TestObject table = null){
		waitForDom2BeStill();
		String script = "";
		if(table == null){
			table = new TestObject("Main Table");
			script = "return document.querySelector('table').id";
			String tableId = execJS(script);
			table.addProperty("id", ConditionType.EQUALS, tableId);
		}

		TestObject actual = getObjectReference(table);

		script = "return document.querySelector('#"+getEveID(actual)+"').querySelectorAll('tr')["+lineIndex+"].querySelector(\"[id^='__item']\").id";
		TestObject checkBox = new TestObject("Line " + lineIndex);

		String checkBoxId = execJS(script);
		checkBox.addProperty("id", ConditionType.EQUALS, checkBoxId);

		WebUI.focus(checkBox);
		WebUI.sendKeys(checkBox, Keys.chord(Keys.SPACE))
	}

	@Keyword
	def goToFilterScreen(){
		waitForDom2BeStill()

		clickOnMenuButton(-3);
		clickOnMenuButton(4);
	}

	@Keyword
	def clickOnMenuButton(int buttonIndex) {
		waitForDom2BeStill();
		
		String buttonId;
		
		try {
			String script = "";

			if(buttonIndex >= 0) script = "let id = document.querySelector(\".sapFDynamicPageTitle\").querySelectorAll(\"button[id^='__button']\")[" +buttonIndex +"].id; return id";
			else script = "let buttons = document.querySelector(\".sapFDynamicPageTitle\").querySelectorAll(\"button[id^='__button']\"); let id = buttons[buttons.length "+ buttonIndex +"].id; return id";

			buttonId = execJS(script)

			TestObject button = new TestObject("Button " + buttonIndex);
			button.addProperty("id", ConditionType.EQUALS, buttonId);

			clickOnObject(button);
			
		} catch (Exception e) {
			if(handleException(e) != true) setStatus(1, "Failed to click on menu button %s", buttonId)
			clickOnMenuButton(buttonIndex);
		}
	}

	@Keyword
	def clickOnObject(TestObject obj){
		TestObject actual = getObjectReference(obj);

		try{
			WebUI.click(actual);
		}
		catch(Exception e){
			if(handleException(e) != true) setStatus(1, "Failed to click on object %s", actual.findPropertyValue("id"))
			clickWithSpace(actual);
		}
	}

	def clickWithSpace(TestObject obj){
		println "Space!";
		try{
			WebUI.focus(obj)
			println "Space 1!";
			WebUI.sendKeys(obj, Keys.SPACE);
			println "Space 2!";
		}
		catch(Exception e){
			setStatus(1, "Failed to hit click on object %s", obj.findPropertyValue("id"))
			println "Space 3!";
		}
	}

	@Keyword
	def setToggle(TestObject obj, String toggleOn){
		if(toggleOn == "1")
			clickOnObject(obj)
	}


	@Keyword
	def checkForError(Boolean stopTest = false){
		String script = "let popup = document.querySelector(\"#popoverLog-popover\"); if(!popup) return ''; let bounds = popup.getBoundingClientRect();  if(bounds.x > 0) return popup.querySelector(\"[id^='__text']\").innerText; return '';";
		String errorText = execJS(script, 1);

		if(errorText != '' && stopTest)
			setStatus(1, "An Error Ocurred : %s", errorText);

		return errorText;
	}


	@Keyword
	def confirmDialogue(int timeout = 3){
		wait(timeout)

		TestObject okButton = new TestObject();
		okButton.addProperty("class", ConditionType.EQUALS, "sapMBtnInner sapMBtnHoverable sapMFocusable sapMBtnText sapMBtnEmphasized");

		clickOnObject(okButton);

		wait(timeout)
	}

	@Keyword
	def getDataFromTable(int lineIndex, int columnIndex, int timeout = 0 ,TestObject table = null){
		waitForDom2BeStill();
		String script = "";

		if(table == null){
			table = new TestObject("Main Table");

			script = "let t = document.querySelector(\"table[id^='__table']\"); if(!t) return 'no_table_present'; return t.id;";
			String tableId = execJS(script);

			if(tableId == "no_table_present") setStatus(1, "Failed to get data from table. No table present.", null);

			table.addProperty("id", ConditionType.EQUALS, tableId);

		}

		TestObject actual = getObjectReference(table);

		try{
			script = "return document.querySelector(\"#"+getEveID(actual)+"\").querySelectorAll('tr')["+lineIndex+"].querySelectorAll('td')["+columnIndex+"].innerText;";
			return execJS(script);
		}
		catch(Exception e){

			if(handleException(e) != true) setStatus(1, "Unable to get data from line %s column %s", lineIndex, columnIndex);
			getDataFromTable(lineIndex, columnIndex, timeout, table);
		}

	}

	@Keyword
	def setDataInTable(int lineIndex, int columnIndex, String text ,int timeout = 3, TestObject table = null){
		waitForDom2BeStill(1);
		String script = "";

		if(table == null){
			table = new TestObject();
			script = "return document.querySelector(\"table[id^='__table']\").id";
			String tableId = execJS(script);
			table.addProperty("id", ConditionType.EQUALS, tableId);
		}

		TestObject actual = getObjectReference(table);
		String data = "";

		try{
			script = "return document.querySelector(\"#"+ getEveID(actual) +"\").querySelectorAll('tr')["+lineIndex+"].querySelectorAll('td')["+ columnIndex+"].querySelector(\"input[type='text']\").id;";

			String inputId = execJS(script);

			TestObject input = new TestObject("Input " + lineIndex + "-" + columnIndex);
			input.addProperty("id", ConditionType.EQUALS, inputId);

			TestObject actualInput = getObjectReference(input);

			if(inputId.startsWith("__box")){
				setDropDownOption(actualInput, text, false)
			}
			else if(inputId.startsWith("__switch")){
				setToggle(actualInput, text);
			}
			else{
				setText(actualInput, text);
			}

		}
		catch(StepFailedException ex){
			setStatus(1, "Unable to set data in line %s column %s", lineIndex, columnIndex);
		}
	}

	// Support

	def setZoom(TestObject obj, int zoom){
		String id = obj.findPropertyValue("id");
		execJS("return document.querySelector('#"+ id + "').style.zoom = '"+zoom+"%'");
	}

	@Keyword
	def checkObjectVisible(TestObject obj, int timeout = 10){
		try{FailureHandling.CONTINUE_ON_FAILURE
			Boolean present = WebUI.waitForElementPresent(obj, timeout);			
			return present;
		}
		catch(Exception e){
			if(handleException(e) != true) setStatus(1, "Failed to check if object is visible");
		}
	}

	def getEveID(TestObject testObject){
		return testObject.findPropertyValue("id")
	}

	def waitForDom2BeStill(timeout = 1){
		String script = "let dummy = async () => { let p = new Promise((resolve) => { let timer = 0; let checkDomStill = () => { timer++; let busyIndicator = document.querySelector(\"[id*='busyIndicator']\"); if (timer >= " + timeout + " && !busyIndicator) { const highestId = window.setInterval(() => { for (let i = highestId; i >= 0; i--) { window.clearInterval(i); }; }, 0); obs.disconnect(); resolve(); } }; setInterval(checkDomStill, 1000); const obs = new MutationObserver((mutationList, observer) => { timer = 0; }); let targetNode = document.body; const config = { attributes: true, childList: true, subtree: true }; obs.observe(targetNode, config); }); await p; return \"dummy\"; }; return dummy();"
		execJS(script);
	}

	def getObjectReference(TestObject testObject){
		waitForDom2BeStill();

		String eveID = WebUI.getAttribute(testObject, "id");

		TestObject actual = new TestObject(testObject.getObjectId());

		actual.addProperty("id", ConditionType.EQUALS, eveID);

		return actual;
	}

	def execJS(script, delay = 0){
		try{
			wait(delay);
			return WebUI.executeJavaScript(script, null);
		}
		catch(e){
			if(handleException(e) != true) setStatus(1, "JavaScript error occurred when executing script %s.", null)
			execJS(script)
		}
	}

	def getInputDisabled(String id){
			String script = "return document.getElementById(\""+id+"\").disabled;"
			Boolean disabled = execJS(script);
			return disabled;
	}

	@Keyword
	def wait(int seconds){
		if(seconds > 0) WebUI.delay(seconds);
	}


	def findPattern(String input, String inputPattern){
		Pattern pattern = Pattern.compile(inputPattern, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(input);
		Boolean matchFound = matcher.find();

		return matchFound;
	}

	@Keyword
	def printMessage(String message, Object... args){
		String newMessage = message;

		Pattern pattern = Pattern.compile("%s", Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(newMessage);
		boolean matchFound = matcher.find();

		if(matchFound) {
			for(Object arg : args) {
				newMessage = newMessage.replaceFirst("%s", arg.toString());
			}
		}

		println newMessage;
	}

	@Keyword
	def setStatus(int status, String message, Object... args) {
		String newMessage = message;

		Pattern pattern = Pattern.compile("%s", Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(newMessage);
		boolean matchFound = matcher.find();

		if(matchFound) {
			for(Object arg : args) {
				newMessage = newMessage.replaceFirst("%s", arg.toString());
			}
		}

		println "STATUS["+status+"] " + "MESSAGE["+newMessage+"]";
		WebUI.takeScreenshot()
		WebUI.closeBrowser();
		Runtime.getRuntime().halt(0);
	}

	def handleException(Exception e){
		switch(e.getCause()){
			case com.kms.katalon.core.exception.StepFailedException :
				println "Step Failed"
				return false;
				break;

			case org.openqa.selenium.StaleElementReferenceException :
				return true;
				break;

			case org.openqa.selenium.ElementClickInterceptedException :
				return true;
				break;

			case com.kms.katalon.core.webui.exception.BrowserNotOpenedException :
				setStatus(1, "No browser opened. All Test Suites have to start with a login test case");
				return false;
				break;

			default :
				setStatus(1, "Unexpected error ocurred. See log.", null)
		}
	}

}
